(() => {
  const view = document.body.dataset.connectView;
  const fetchFromSimo = window.fetch.bind(window);
  const prefixes = ["/api/simo-connect/", "/api/simo-calling/"];
  let reloading = false;

  // Keep each open Connect view bound to the account that loaded it.
  window.fetch = async (input, options) => {
    const url = new URL(input instanceof Request ? input.url : input, location.href);
    if (url.origin !== location.origin || !prefixes.some(prefix => url.pathname.startsWith(prefix))) {
      return fetchFromSimo(input, options);
    }

    const headers = new Headers(options?.headers ?? (input instanceof Request ? input.headers : undefined));
    headers.set("X-Simo-Connect-View", view);
    const response = await fetchFromSimo(input, {...options, headers});
    if (!reloading && response.headers.get("X-Simo-Connect-View") === "stale") {
      reloading = true;
      location.reload();
    }
    return response;
  };
})();
