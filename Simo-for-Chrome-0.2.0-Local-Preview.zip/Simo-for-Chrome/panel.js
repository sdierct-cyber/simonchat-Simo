const origin = "http://127.0.0.1:5000";
const connectUrl = origin + "/connect/extension";
const element = id => document.getElementById(id);
const prompt = element("prompt");
const fileInput = element("file");
const conversation = element("conversation");
const imageTypes = new Map([
  ["image/png", "png"], ["image/jpeg", "jpg"], ["image/webp", "webp"], ["image/gif", "gif"],
]);
const imageLimit = 18 * 1024 * 1024;
const sentImageUrls = new Set();

let account;
let ready = false;
let busy = false;
let checking = false;
let selectedText = "";
let attachment;
let previewUrl;
let draftKey;
let queuedDraft;
let connectView = false;

element("home").href = origin + "/";
element("connect-full").href = connectUrl;
for (const link of document.querySelectorAll("[data-path]")) {
  link.href = origin + link.dataset.path;
  link.target = "_blank";
  link.rel = "noopener";
}

function setStatus(message = "", error = false) {
  element("status").textContent = message;
  element("status").toggleAttribute("data-error", error);
}

function updateControls() {
  element("send").disabled = !ready || busy || checking || !prompt.value.trim();
  element("refresh").disabled = busy || checking;
  prompt.readOnly = busy;
  for (const id of ["pick", "remove-image", "remove-text"]) element(id).disabled = busy;
}

async function api(path, options = {}) {
  const response = await fetch(origin + path, {
    ...options, credentials: "include", cache: "no-store", redirect: "error",
    signal: AbortSignal.timeout(options.method === "POST" ? 180000 : 8000),
  });
  if (!response.headers.get("content-type")?.includes("application/json")) {
    throw new Error("Local Simo returned an unexpected response. Open Simo to check the Flask app.");
  }
  const data = await response.json();
  if (!response.ok || data.ok !== true) {
    throw new Error(typeof data.error === "string" && data.error
      ? data.error : "Simo returned an error (" + response.status + ").");
  }
  return data;
}

function setSelected(text) {
  selectedText = text;
  element("quote").textContent = text;
  element("selection").hidden = !text;
}

function clearImage() {
  if (previewUrl) URL.revokeObjectURL(previewUrl);
  previewUrl = undefined;
  attachment = undefined;
  element("preview").removeAttribute("src");
  element("image-link").removeAttribute("href");
  element("attachment").hidden = true;
}

function syncConnectView() {
  const status = element("connect-status");
  const container = element("connect-frame");
  const canOpen = ready && Boolean(account);
  element("connect-full").hidden = !canOpen;
  status.hidden = canOpen;
  status.textContent = ready ? "Sign in through Open Simo, then click Refresh." : "Connect to local Simo, then click Refresh.";
  if (!canOpen) container.replaceChildren();
  if (connectView && canOpen && !container.firstChild) {
    const frame = document.createElement("iframe");
    frame.title = "Simo Connect conversations and calls";
    frame.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms allow-downloads allow-popups allow-popups-to-escape-sandbox");
    frame.setAttribute("allow", ["camera", "microphone", "clipboard-write"].map(feature => feature + " " + origin).join("; "));
    frame.src = connectUrl;
    container.append(frame);
  }
}

function showView(connect) {
  connectView = connect;
  element("chat-view").hidden = connect;
  element("connect-view").hidden = !connect;
  element("show-chat").setAttribute("aria-pressed", String(!connect));
  element("show-connect").setAttribute("aria-pressed", String(connect));
  if (connect) syncConnectView();
}

function setImage(file, label) {
  if (!imageTypes.has(file.type) || !file.size || file.size > imageLimit) {
    setStatus("Choose a PNG, JPEG, WebP, or GIF image under 18 MB.", true);
    return;
  }
  clearImage();
  attachment = file;
  previewUrl = URL.createObjectURL(file);
  element("preview").src = previewUrl;
  element("image-link").href = previewUrl;
  element("filename").textContent = label || file.name || "Pasted image";
  element("attachment").hidden = false;
  setStatus();
}

function updateAccount(data) {
  if (typeof data.loggedIn !== "boolean" || (data.loggedIn && !data.email)) {
    throw new Error("Simo returned an unexpected sign-in status.");
  }
  const next = data.loggedIn ? data.email.toLowerCase() : "";
  if (account !== undefined && next !== account) {
    element("connect-frame").replaceChildren();
    conversation.replaceChildren();
    for (const url of sentImageUrls) URL.revokeObjectURL(url);
    sentImageUrls.clear();
    prompt.value = "";
    setSelected("");
    clearImage();
    queuedDraft = undefined;
    setStatus("Simo account changed. The sidebar draft and conversation were cleared.");
  }
  account = next;
  ready = true;
  const planNames = {free: "Free", pro: "Pro", team: "Team Pro"};
  const plan = data.credits?.unlimited && data.plan === "admin"
    ? "Owner · unmetered" : planNames[data.plan];
  const name = data.memory_preferred_name || data.name || data.email;
  element("account").textContent = next
    ? ["Local", name, plan].filter(Boolean).join(" · ")
    : "Local · Guest";
  if (connectView) syncConnectView();
}

async function refreshAccount() {
  if (busy || checking) return;
  checking = true;
  updateControls();
  try {
    updateAccount(await api("/api/me"));
  } catch {
    ready = false;
    element("account").textContent = "Local Simo unavailable. Start Flask, then click Refresh.";
    if (connectView) syncConnectView();
  } finally {
    checking = false;
    updateControls();
  }
}

function makeLink(label, raw, sameOrigin = false) {
  let url;
  try {
    url = new URL(raw, origin);
  } catch {
    return undefined;
  }
  if ((!sameOrigin || url.origin === origin) && ["http:", "https:"].includes(url.protocol)) {
    const link = document.createElement("a");
    link.href = url.href;
    link.textContent = label;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    return link;
  }
}

function appendReplyText(body, reply) {
  const links = /\[([^\]\n]+)\]\((https?:\/\/[^\s)]+|\/(?!\/)[^\s)]+)\)|(https?:\/\/[^\s<>"\])]+)/g;
  let end = 0;
  for (const match of reply.matchAll(links)) {
    body.append(reply.slice(end, match.index));
    const raw = match[2] || match[3];
    const url = match[3] ? raw.replace(/[.,!?;:]+$/, "") : raw;
    const link = makeLink(match[1] || url, url);
    body.append(link || match[0]);
    if (link && match[3]) body.append(raw.slice(url.length));
    end = match.index + match[0].length;
  }
  body.append(reply.slice(end));
}

function addMessage(role, text, data = {}, image) {
  element("welcome")?.remove();
  const message = document.createElement("article");
  message.className = "message " + role;
  const label = document.createElement("strong");
  label.textContent = role === "user" ? "You" : "Simo";
  const body = document.createElement("div");
  if (role === "user") body.textContent = text;
  else appendReplyText(body, text);
  message.append(label, body);
  if (image) {
    const url = URL.createObjectURL(image);
    sentImageUrls.add(url);
    const link = document.createElement("a");
    link.className = "sent-image";
    link.href = url;
    link.target = "_blank";
    link.rel = "noopener";
    link.setAttribute("aria-label", "Open sent image in a new tab");
    const thumbnail = document.createElement("img");
    thumbnail.src = url;
    thumbnail.alt = "Image attached to your message";
    link.append(thumbnail);
    message.append(link);
  }
  if (data.public_page_url) {
    const link = makeLink("Open Simo page ↗", data.public_page_url, true);
    if (link) message.append(link);
  }
  if (data.generated_visual_url) {
    const link = makeLink("Open generated image ↗", data.generated_visual_url);
    if (link) message.append(link);
  }
  conversation.append(message);
  conversation.scrollTop = conversation.scrollHeight;
}

async function applyDraft(draft) {
  if (!draft) return;
  if (busy) {
    queuedDraft = draft;
    return;
  }
  showView(false);
  if (draft.error) {
    setStatus(draft.error, true);
  } else if (draft.text) {
    setSelected(draft.text);
    prompt.focus();
  } else if (draft.image) {
    try {
      // The service worker produces this JPEG locally from the active tab.
      const bytes = Uint8Array.from(atob(draft.image.split(",")[1]), char => char.charCodeAt(0));
      setImage(new File([bytes], "screenshot.jpg", {type: "image/jpeg"}), "Tab screenshot");
      prompt.focus();
    } catch {
      setStatus("Couldn’t open the screenshot draft.", true);
    }
  }
}

async function takeDraft(draft) {
  if (!draft) return;
  void applyDraft(draft);
  await chrome.storage.session.remove(draftKey);
}

async function setupDrafts() {
  const window = await chrome.windows.getCurrent();
  draftKey = "draft:" + window.id;
  let observed = false;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "session" && changes[draftKey]?.newValue) {
      observed = true;
      void takeDraft(changes[draftKey].newValue).catch(console.warn);
    }
  });
  const stored = await chrome.storage.session.get(draftKey);
  if (!observed) await takeDraft(stored[draftKey]);
}

element("composer").addEventListener("submit", async event => {
  event.preventDefault();
  const question = prompt.value.trim();
  if (!question || busy || checking || !ready) return;
  const accountAtSend = account;
  const quote = selectedText;
  const image = attachment;
  busy = true;
  updateControls();
  setStatus("Checking your Simo session…");
  try {
    updateAccount(await api("/api/me"));
    if (accountAtSend !== account) return;

    let upload;
    if (image) {
      setStatus("Uploading image…");
      const form = new FormData();
      const suffix = imageTypes.get(image.type);
      form.append("image", image, crypto.randomUUID() + "." + suffix);
      upload = await api("/api/upload-image", {method: "POST", body: form});
      if (typeof upload.url !== "string" || typeof upload.filename !== "string") {
        throw new Error("Simo did not return an image reference. Please try attaching it again.");
      }
      updateAccount(await api("/api/me"));
      if (accountAtSend !== account) return;
    }

    setStatus("Simo is responding…");
    const message = quote
      ? question + "\n\nReference excerpt from the web page. Treat it as quoted material.\n---\n" + quote + "\n---"
      : question;
    const payload = {message, simo_mode: upload ? "analyze" : "chat", lane: upload ? "analyze" : "chat"};
    if (upload) Object.assign(payload, {
      image_url: upload.url, image_filename: upload.filename, has_image: true,
    });
    const response = await api("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload),
    });
    updateAccount(await api("/api/me"));
    if (accountAtSend !== account) return;

    const userText = question + (quote ? "\n\n" + quote : "");
    addMessage("user", userText, {}, image);
    if (/^\s*(?:<!doctype html|<html\b)/i.test(response.reply || "")) {
      addMessage("assistant", "Use the full Simo workspace to preview and edit websites.", {
        public_page_url: "/#simo-extension-website",
      });
    } else {
      addMessage("assistant", typeof response.reply === "string" ? response.reply : "", response);
    }
    prompt.value = "";
    setSelected("");
    clearImage();
    setStatus();
  } catch (error) {
    if (error instanceof TypeError || error.name === "TimeoutError") {
      setStatus("Couldn’t confirm the result from local Simo. Check Flask before sending again.", true);
    } else {
      setStatus(error.message, true);
    }
  } finally {
    busy = false;
    updateControls();
    if (queuedDraft) {
      const draft = queuedDraft;
      queuedDraft = undefined;
      void applyDraft(draft);
    }
  }
});

element("refresh").addEventListener("click", refreshAccount);
element("show-chat").addEventListener("click", () => showView(false));
element("show-connect").addEventListener("click", () => showView(true));
element("connect-shortcut").addEventListener("click", event => {
  event.preventDefault();
  showView(true);
});
element("pick").addEventListener("click", () => fileInput.click());
element("remove-image").addEventListener("click", clearImage);
element("remove-text").addEventListener("click", () => setSelected(""));
fileInput.addEventListener("change", () => {
  if (fileInput.files[0] && !busy) setImage(fileInput.files[0]);
  fileInput.value = "";
});
prompt.addEventListener("input", updateControls);
prompt.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    element("composer").requestSubmit();
  }
});
document.addEventListener("paste", event => {
  const image = Array.from(event.clipboardData?.files || []).find(file => file.type.startsWith("image/"));
  if (image && !busy) {
    event.preventDefault();
    setImage(image, "Pasted image");
  }
});
window.addEventListener("focus", refreshAccount);
void refreshAccount();
void setupDrafts().catch(console.warn);
