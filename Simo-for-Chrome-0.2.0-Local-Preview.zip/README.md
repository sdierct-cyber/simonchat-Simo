# Simo for Chrome 0.2.0

This is a developer preview for a local Simo Flask server on `http://127.0.0.1:5000`.
It does not connect to simonchat.ai. Desktop Chrome is the tested browser.
This folder contains the unpacked extension and a local server adapter.

## Install the local preview

1. Run a working local copy of Simo with its current Connect modules and static files.
2. Copy the files inside `SimoAI-project` to the matching locations in your local project.
   Replace `simo_connect_signin_guard.py` beside `app.py` and copy the added
   files into the existing `static` and `templates` directories.
3. On desktop Chrome, open `chrome://extensions`, enable Developer mode, click
   **Load unpacked**, and select `Simo-for-Chrome`, which contains `manifest.json`.
4. Copy the 32-letter ID from the extension card. Set the environment variable
   `SIMO_CONNECT_EXTENSION_ID` to that value before starting Flask, for example
   in PowerShell:

   ```powershell
   $env:SIMO_CONNECT_EXTENSION_ID = 'YOUR_EXTENSION_ID'
   python app.py
   ```

5. Open `http://127.0.0.1:5000`, sign in, and open Simo from Chrome's Extensions menu.
   Use **Refresh** to update the account shown in the panel.

The preview includes chat, selected-text and image input, workspace shortcuts,
and a local Simo Connect panel. Flask tests cover messaging, attachment access,
and one-to-one voice and video signaling. Live browser audio and video still need
an end-to-end check. The Connect preview is restricted to the configured
extension and local server, with Simo's existing sign-in and rate limits.
